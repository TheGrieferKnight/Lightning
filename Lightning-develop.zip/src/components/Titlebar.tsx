import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Minus, Square, Copy, X } from "lucide-react";
import { getCurrentWindow, type ResizeDirection } from "@tauri-apps/api/window";

const win = getCurrentWindow();

export const Titlebar: React.FC = () => {
  const [isMax, setIsMax] = useState(false);
  const dragRef = useRef<HTMLDivElement | null>(null);

  const refreshMax = useCallback(async () => {
    try {
      setIsMax(await win.isMaximized());
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    void refreshMax();
  }, [refreshMax]);

  const onMinimize = async () => {
    await win.minimize();
  };

  const onToggleMax = async () => {
    await win.toggleMaximize();
    await refreshMax();
  };

  const onClose = async () => {
    await win.close();
  };

  // Double‑click drag region to toggle maximize (native feel)
  const onDoubleClick = async (e: React.MouseEvent) => {
    // Don’t toggle if the user double‑clicked the button group.
    const isButtonGroup =
      (e.target as HTMLElement).closest("[data-window-controls]") != null;
    if (!isButtonGroup) {
      await onToggleMax();
    }
  };

  const borderClass = useMemo(
    () =>
      "pointer-events-none fixed inset-0 " +
      "rounded-xl " +
      "shadow-[0_10px_30px_-10px_rgba(0,0,0,0.6)] " +
      // Outer subtle gradient border
      "ring-1 ring-white/6",
    []
  );

  return (
    <>
      {/* Gradient border + shadow (inside webview) */}
      <div className={borderClass} />

      {/* Titlebar */}
      <div
        className={
          "fixed top-0 left-0 right-0 z-50 " +
          "h-11 px-3 flex items-center justify-between " +
          // Glass gradient + blur + inner divider
          "bg-gradient-to-r from-[#0b1220]/80 via-[#0b1220]/40 to-[#0b1220]/80 " +
          "backdrop-blur-xl border-b border-white/10"
        }
        onDoubleClick={onDoubleClick}
      >
        {/* Drag region (brand) */}
        <div
          ref={dragRef}
          data-tauri-drag-region
          className="flex items-center gap-2 select-none"
        >
          <div
            className={
              "h-6 w-6 rounded-md " +
              "bg-gradient-to-br from-cyan-400/30 to-blue-500/20 " +
              "ring-1 ring-cyan-400/30"
            }
          />
          <span className="text-sm font-semibold text-cyan-200">Lightning</span>
        </div>

        {/* Controls */}
        <div
          data-window-controls
          className={
            "flex items-center gap-1 " +
            "rounded-lg bg-white/5 p-0.5 " +
            "shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]"
          }
        >
          <TitlebarBtn
            label="Minimize"
            onClick={onMinimize}
            icon={<Minus className="h-3.5 w-3.5" />}
          />
          <TitlebarBtn
            label={isMax ? "Restore" : "Maximize"}
            onClick={onToggleMax}
            icon={
              isMax ? (
                <Copy className="h-3.5 w-3.5" />
              ) : (
                <Square className="h-3.5 w-3.5" />
              )
            }
          />
          <TitlebarBtn
            label="Close"
            onClick={onClose}
            accent="danger"
            icon={<X className="h-3.5 w-3.5" />}
          />
        </div>
      </div>

      <ResizeHandles />
    </>
  );
};

function TitlebarBtn(props: {
  label: string;
  icon: React.ReactNode;
  onClick: () => void | Promise<void>;
  accent?: "danger" | "normal";
}) {
  const { label, icon, onClick, accent = "normal" } = props;

  const base =
    "h-8 w-8 rounded-md grid place-items-center transition " +
    "text-cyan-100/80 hover:text-cyan-100 focus:outline-none";

  const normalHover = "hover:bg-white/10";
  const dangerHover =
    "hover:bg-red-500/20 hover:text-red-200 " +
    "focus-visible:ring-2 focus-visible:ring-red-400/40";

  return (
    <button
      aria-label={label}
      title={label}
      onClick={onClick}
      className={`${base} ${accent === "danger" ? dangerHover : normalHover}`}
    >
      {icon}
    </button>
  );
}

const ResizeHandles: React.FC = () => {
  const start = async (edge: ResizeDirection) => {
    try {
      await win.startResizeDragging(edge);
    } catch {
      /* ignore */
    }
  };

  // 8px handles (easier to grab), corners 12px
  return (
    <>
      <div
        className="fixed top-0 left-0 right-0 h-2 cursor-n-resize"
        onMouseDown={() => void start("North")}
      />
      <div
        className="fixed bottom-0 left-0 right-0 h-2 cursor-s-resize"
        onMouseDown={() => void start("South")}
      />
      <div
        className="fixed top-0 bottom-0 left-0 w-2 cursor-w-resize"
        onMouseDown={() => void start("West")}
      />
      <div
        className="fixed top-0 bottom-0 right-0 w-2 cursor-e-resize"
        onMouseDown={() => void start("East")}
      />

      <div
        className="fixed top-0 left-0 w-3 h-3 cursor-nw-resize"
        onMouseDown={() => void start("NorthWest")}
      />
      <div
        className="fixed top-0 right-0 w-3 h-3 cursor-ne-resize"
        onMouseDown={() => void start("NorthEast")}
      />
      <div
        className="fixed bottom-0 left-0 w-3 h-3 cursor-sw-resize"
        onMouseDown={() => void start("SouthWest")}
      />
      <div
        className="fixed bottom-0 right-0 w-3 h-3 cursor-se-resize"
        onMouseDown={() => void start("SouthEast")}
      />
    </>
  );
};
