// src/components/SummonerProfile.tsx

import React from "react";
import { Star, Trophy, Target } from "lucide-react";
import { SummonerData } from "../types/dashboard";
import { getSummonerImageUrl } from "../utils/imageUtils";
interface SummonerProfileProps {
  summoner: SummonerData;
}

export const SummonerProfile: React.FC<SummonerProfileProps> = ({
  summoner,
}) => (
  <div className="bg-neutral-900/50 supports-[backdrop-filter]:backdrop-blur-sm rounded-2xl p-8 mb-8 border border-neutral-800/60 has-noise">
    <div className="flex items-center space-x-6">
      <div className="w-24 h-24 rounded-2xl bg-avatar-gradient-smooth has-noise-light flex items-center justify-center text-3xl font-bold">
        <img src={getSummonerImageUrl(summoner.profileIconPath)}></img>
      </div>
      <div className="flex-1">
        <h2 className="text-3xl font-bold text-white mb-2">
          {summoner.displayName}
        </h2>
        <div className="flex items-center space-x-4 text-cyan-300">
          <span className="flex items-center space-x-1">
            <Star className="w-4 h-4" />
            <span>Level {summoner.level}</span>
          </span>
          <span className="flex items-center space-x-1">
            <Trophy className="w-4 h-4" />
            <span>
              {summoner.rank.tier} {summoner.rank.division}
            </span>
          </span>
          <span className="flex items-center space-x-1">
            <Target className="w-4 h-4" />
            <span>{summoner.rank.lp} LP</span>
          </span>
        </div>
        <div className="mt-2 text-sm text-cyan-300/80">
          Main: {summoner.mainChampion} • Role: {summoner.favoriteRole}
        </div>
      </div>
    </div>
  </div>
);
