// src/components/ChampionMasteryCard.tsx

import React from "react";
import { ChampionMasteryCardProps } from "../types/dashboard";
import { getMasteryLevelColor, formatNumber } from "../utils/dashboardUtils";

export const ChampionMasteryCard: React.FC<ChampionMasteryCardProps> = ({
  champion,
}) => (
  <div className="bg-neutral-900/50 rounded-lg p-4 hover:bg-neutral-900/70 transition-colors duration-200 motion-reduce:transition-none has-noise">
    <div className="flex items-center space-x-3">
      <div className="w-12 h-12 rounded-full bg-neutral-800 flex items-center justify-center text-xl">
        {champion.icon}
      </div>
      <div className="flex-1">
        <h4 className="font-semibold text-white">{champion.name}</h4>
        <div className="flex items-center space-x-2">
          <span
            className={`text-xs px-2 py-1 rounded ${getMasteryLevelColor(
              champion.level
            )}`}
          >
            Level {champion.level}
          </span>
          <span className="text-xs text-cyan-300">
            {formatNumber(champion.points)} pts
          </span>
        </div>
      </div>
    </div>
  </div>
);
