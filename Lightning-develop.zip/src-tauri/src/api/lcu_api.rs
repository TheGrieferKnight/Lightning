use base64::{engine::general_purpose, Engine as _};
use reqwest;
use serde::{Deserialize, Serialize};
use std::io;
use std::num::ParseIntError;
use std::path::Path;
use tokio::fs::File;
use tokio::io::AsyncReadExt;

/// Errors that can occur when interacting with the LCU API.
#[derive(Debug)]
pub enum LockfileError {
    Io(io::Error),
    Parse(String),
    Request(reqwest::Error),
    Json(serde_json::Error),
}

impl From<io::Error> for LockfileError {
    fn from(err: io::Error) -> Self {
        LockfileError::Io(err)
    }
}
impl From<ParseIntError> for LockfileError {
    fn from(err: ParseIntError) -> Self {
        LockfileError::Parse(format!("Failed to parse number: {err}"))
    }
}
impl From<reqwest::Error> for LockfileError {
    fn from(err: reqwest::Error) -> Self {
        LockfileError::Request(err)
    }
}
impl From<serde_json::Error> for LockfileError {
    fn from(err: serde_json::Error) -> Self {
        LockfileError::Json(err)
    }
}
impl std::fmt::Display for LockfileError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            LockfileError::Io(err) => write!(f, "IO error: {err}"),
            LockfileError::Parse(msg) => write!(f, "Parse error: {msg}"),
            LockfileError::Request(err) => write!(f, "Request error: {err}"),
            LockfileError::Json(err) => write!(f, "JSON error: {err}"),
        }
    }
}
impl std::error::Error for LockfileError {}

/// Represents the current summoner.
#[derive(Debug, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CurrentSummoner {
    pub puuid: String,
    pub summoner_id: u64,
    pub account_id: u64,
    pub display_name: String,
    pub summoner_level: u32,
    pub profile_icon_id: i32,
    pub game_name: String,
    pub tag_line: String,
}

/// Represents the League Client lockfile.
pub struct Lockfile {
    _league_client: String,
    _process_id: i32,
    pub api_port: i32,
    pub password: String,
    _protocol: String,
}

impl Lockfile {
    async fn new() -> Result<Self, LockfileError> {
        let contents = Self::locate_lockfile().await?;
        Self::parse_lockfile_contents(&contents)
    }

    async fn locate_lockfile() -> Result<String, io::Error> {
        let path = Path::new("C:/Program Files/Riot Games/League of Legends/lockfile");
        let mut file = File::open(path).await?;
        let mut contents = String::new();
        file.read_to_string(&mut contents).await?;
        Ok(contents)
    }

    fn parse_lockfile_contents(contents: &str) -> Result<Self, LockfileError> {
        let parts: Vec<&str> = contents.trim().split(':').collect();
        if parts.len() != 5 {
            return Err(LockfileError::Parse(format!(
                "Unexpected lockfile format: got {} parts",
                parts.len()
            )));
        }
        Ok(Lockfile {
            _league_client: parts[0].to_string(),
            _process_id: parts[1].parse::<i32>()?,
            api_port: parts[2].parse::<i32>()?,
            password: parts[3].to_string(),
            _protocol: parts[4].to_string(),
        })
    }

    fn create_client(&self) -> Result<reqwest::Client, LockfileError> {
        Ok(reqwest::Client::builder()
            .danger_accept_invalid_certs(true)
            .build()?)
    }

    fn get_auth_header(&self) -> String {
        let credentials = format!("riot:{}", self.password);
        format!("Basic {}", general_purpose::STANDARD.encode(credentials))
    }

    fn get_base_url(&self) -> String {
        format!("https://127.0.0.1:{}", self.api_port)
    }
}

impl std::fmt::Display for Lockfile {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
          f,
          "Lockfile {{\n  Client: {}\n  PID: {}\n  API Port: {}\n  Password: [HIDDEN]\n  Protocol: {}\n}}",
          self._league_client, self._process_id, self.api_port, self._protocol
      )
    }
}

/// High-level LCU API client.
pub struct LeagueApiClient {
    pub(crate) lockfile: Lockfile,
    client: reqwest::Client,
}

impl LeagueApiClient {
    pub async fn new() -> Result<Self, LockfileError> {
        let lockfile = Lockfile::new().await?;
        let client = lockfile.create_client()?;
        Ok(Self { lockfile, client })
    }

    pub async fn get_current_summoner(&self) -> Result<CurrentSummoner, LockfileError> {
        let url = format!(
            "{}/lol-summoner/v1/current-summoner",
            self.lockfile.get_base_url()
        );
        let response = self
            .client
            .get(&url)
            .header("Authorization", self.lockfile.get_auth_header())
            .send()
            .await?;
        if !response.status().is_success() {
            return Err(LockfileError::Parse(format!(
                "HTTP error {}",
                response.status()
            )));
        }
        Ok(response.json::<CurrentSummoner>().await?)
    }

    pub async fn get_game_name(&self) -> Result<String, LockfileError> {
        Ok(self.get_current_summoner().await?.game_name)
    }

    pub async fn get_tag_line(&self) -> Result<String, LockfileError> {
        Ok(self.get_current_summoner().await?.tag_line)
    }
}
